const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web8.js","./index.js","./index.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index.js";const t=e("GoogleAuth",{web:()=>o(()=>import("./web8.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.GoogleAuthWeb)});export{t as GoogleAuth};
